#!/bin/sh

D=`date +'%F_%H-%M-%S'`
echo "Backup old root.sqfs to root.sqfs.$D"
mv -f /mnt/data/public/root.sqfs /mnt/data/public/root.sqfs.$D
echo "SQUASHING"
sqfs/mksquashfs /mnt/data/public/squashfs-root /mnt/data/public/root.sqfs
ls -l /mnt/data/public/root.sqfs
SZ=`stat /mnt/data/public/root.sqfs | grep Size | awk '{print $2}'`
ZR=$((6094848-$SZ))
echo "Make ZERO fill $ZR byte(s)"
dd if=/dev/zero of=/mnt/data/public/zerro.bin bs=1 count=$ZR
echo "Merging root.sqfs"
cat /mnt/data/public/zerro.bin >> /mnt/data/public/root.sqfs
#echo -n "01030107Supercom" >> /mnt/data/public/root.sqfs
ls -l /mnt/data/public/root.sqfs
ls -l /mnt/data/public/mtdb*3.bin
echo "dd if=/mnt/data/public/root.sqfs of=/dev/mtdblock3"
chmod ugo+rw /mnt/data/public/root.sq*

