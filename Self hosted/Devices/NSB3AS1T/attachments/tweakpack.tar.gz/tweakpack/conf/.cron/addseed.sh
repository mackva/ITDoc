#!/bin/sh
TR="$@"
MD5=`echo "$TR" | md5sum | awk '{print $1}'`
echo "$MD5 | $TR" >> /conf/.cron/seed.md5

