#!/bin/sh
TR=$1
MD5=`echo "$TR" | md5sum | awk '{print $1}'`
cat /conf/.cron/seed.md5 | grep -v grep | grep "$MD5"

