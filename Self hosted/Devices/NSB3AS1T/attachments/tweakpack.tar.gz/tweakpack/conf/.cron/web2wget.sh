#!/bin/sh

[ -s /conf/.cron/web2wget.conf ] || exit 0
. /conf/.cron/web2wget.conf

[ -e $QFILE ] || touch $QFILE

S=$@
STOP=`echo -n "$S" | awk -F"|" '{print $1}'`
CLR=`echo -n "$S" | awk -F"|" '{print $2}'`
LINK=`echo -n "$S" | awk -F"|" '{print $4}'`
TRSH=`echo -n "$S" | awk -F"|" '{print $3}'`

L=${#STOP}
[ $L -eq 0 ] && STOP=0 || STOP=1
[ $STOP -eq 1 ] && killall wget > /dev/null 2>&1

L=${#CLR}
if [ $L -ne 0 ]; then
  MD5=`echo "$CLR" | md5sum | awk '{print $1}'`
  cat $QFILE | grep -v $MD5 > /conf/qfile 
  mv /conf/qfile $QFILE
  chmod 666 $QFILE 2>/dev/null
fi

L=${#TRSH}
if [ $L -ge 1 ]; then
  rm -f $QFILE 2>/dev/null
  touch $QFILE 2>/dev/null
  chmod 666 $QFILE 2>/dev/null
  rm -f $WDIR/*.log 2>/dev/null
  rm -f $WDIR/*.err 2>/dev/null
fi

L=${#LINK}
[ $L -le 0 ] && exit 0
MD5=`echo "$LINK" | md5sum | awk '{print $1}'`
EX=`cat $QFILE | grep -c "$MD5"`
[ $EX -le 0 ] && echo "$MD5|$LINK" >> $QFILE
chmod 666 $QFILE

sleep 2
/conf/.cron/get.sh

