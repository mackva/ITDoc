#!/bin/sh

#exit 0
if [ -f /conf/.cron/isrun.lock ]; then
    exit 0
fi

touch /conf/.cron/isrun.lock

if [ `netstat -lean | grep -c 9091` -le 0 ]; then
    if [ -d /mnt/data/public ]; then
            export TRANSMISSION_WEB_HOME=/conf/transmission/web
            nice -n 10 /conf/.cron/transmission-daemon -g /conf/.config
            touch /conf/.cron/firstrun.lock
    fi
fi

if [ `netstat -lean | grep -c 9091` -ge 1 ]; then
    if [ ! -f /conf/.cron/firstrun.lock ]; then
        nice -n 10 /conf/.cron/queue.sh
    fi
fi

NTP=`cat /etc/crontab | grep ntpdate | grep -v grep | wc -l`
[ $NTP -lt 1 ] && echo "0 1 * * * root /usr/sbin/ntpdate  ntp.belbone.be >/dev/null 2>&1 &" >> /etc/crontab

rm -f /conf/.cron/isrun.lock
rm -f /conf/.cron/firstrun.lock

/conf/.cron/get.sh
