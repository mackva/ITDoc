#!/conf/.cron/haserl
content-type: text/html

<html><body>
<h1>WGET downloader</h1>
<form action="<% /conf/.cron/web2wget.sh $( echo -n "$FORM_stopper|$FORM_cleaner|$FORM_trash|$FORM_textfield" ) %>" method="GET">
<input type=text name=textfield>
<input type=submit value=GO><br />
<input type=checkbox name=stopper>Stop download<br />
<input type=checkbox name=trash>Clear queue<br />
Delete link from queue:<br />
<select name=cleaner>
<% /conf/.cron/dlist.sh %>
</select>
</form>
<% /conf/.cron/list_wget.sh %>
<% /conf/.cron/list_queue.sh %>
</body>
</html>
