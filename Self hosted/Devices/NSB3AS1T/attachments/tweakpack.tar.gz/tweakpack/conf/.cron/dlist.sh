#!/bin/sh
[ -s /conf/.cron/web2wget.conf ] || exit 1
. /conf/.cron/web2wget.conf

echo "<option>"
L=`ls -1 $WDIR/*.log 2>/dev/null | wc -l`
[ $L -le 0 ] && exit 0
for i in `ls -1 $WDIR/*.log`
do
  FNAME=`basename $i .log`
  break
done
cat $QFILE | grep -v $FNAME | awk -F"|" '{print "<option>"$2}'
