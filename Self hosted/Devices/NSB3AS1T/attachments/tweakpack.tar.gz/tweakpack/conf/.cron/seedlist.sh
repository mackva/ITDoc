#!/bin/sh
# Copyright (c) 2010 Tomas Carnecky

# *************
# Path to transmission-remote
PASS="user:password"
REMOTE="/conf/.config/transmission-remote 127.0.0.1:9091 -n $PASS"

# *************
# List all torrents
LIST="$($REMOTE -l | grep -v "Status" | grep -v "^Sum\:" | awk '{ print $1; }')"
for ID in $LIST; do
    NAME="$($REMOTE -t $ID -i | grep Name:)"
    NAME="${NAME#*Name: }"
    MD5=`echo "$NAME" | md5sum | awk '{print $1}'`
    echo "$MD5 | $NAME"
done
