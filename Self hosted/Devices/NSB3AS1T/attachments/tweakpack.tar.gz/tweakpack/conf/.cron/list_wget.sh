#!/bin/sh
[ -s /conf/.cron/web2wget.conf ] || exit 0
. /conf/.cron/web2wget.conf

NFILES=`ls -1 $WDIR/*.log 2>/dev/null | wc -l`
if [ $NFILES -le 0 ]; then
  echo "<h2>No files downloadin' now</h2>"
else
  echo "<hr /><h2>Now downloading</h2><table border=1><tr><th>File</th><th>Downloaded</th><th>Try</th></tr>"
  for i in `ls -1 $WDIR/*.log`
  do
    FNAME=`basename $i .log`
    ENAME=`dirname $i`
    ENAME="$ENAME/$FNAME".err
    [ -s $ENAME ] && TRY=`cat $ENAME` || TRY=0
    SIZE=`cat $i | grep "%" | tail -n 1 | awk '{print $1}'`
    L=${#SIZE}
    if [ $L -eq 0 ]; then
      SIZE=`cat $i | grep -c "100%"`
      [ $SIZE -eq 0 ] || SIZE="Done"
    fi
    LINK=`cat $QFILE | grep $FNAME | awk -F"|" '{print $2}'`
    LINK=`basename "$LINK"`
    echo "<tr><td>$LINK</td><td align=right>$SIZE</td><td align=center>$TRY</td></tr>"
  done
  echo "</table>"
  [ `ps -w | grep -v grep | grep -c $WGET` -eq 0 ] && echo "<h2>No WGET running</h2>" || echo "<h2>WGET is running</h2>"
fi
