/conf/.cron/transmission-remote 127.0.0.1:9091 -n "user:password" -t all --start

