#!/bin/sh
QFILE=/conf/.cron/wget.queue

if [ -s $QFILE ]; then
  echo "<hr /><h2>Download queue</h2><ul>"
  LEN=`cat "$QFILE" | wc -l`
  J=1      
  while [ $J -le $LEN ];          
  do              
    S=`cat "$QFILE" | tail -n +$J | head -n 1 | awk -F"|" '{print $2}'`
    L=${#S}                        
    [ $L -gt 0 ] && echo "<li>`basename $S`"        
    J=$((J+1))                                                                                     
  done                                                                                             
  echo "</ul>"                                                                                  
fi 
